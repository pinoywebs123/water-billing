<aside>
      <div id="sidebar" class="nav-collapse ">
      
        <ul class="sidebar-menu">
          <li class="active">
            <a class="" href="<?php echo e(route('cashier_home')); ?>">
                  <i class="icon_house_alt"></i>
                  <span>Home</span>
            </a>
          </li>

          <li >
            <a class="" href="<?php echo e(route('cashier_client_records')); ?>">
                  <i class="icon_house_alt"></i>
                  <span>Client Records</span>
            </a>
          </li>

       
          
        
          
        </ul>
        
      </div>
    </aside><?php /**PATH C:\Users\estela\Desktop\THESIS\water_billing\resources\views/cashier/side.blade.php ENDPATH**/ ?>