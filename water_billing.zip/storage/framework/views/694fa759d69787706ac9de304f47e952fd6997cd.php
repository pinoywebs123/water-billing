<aside>
      <div id="sidebar" class="nav-collapse ">
      
        <ul class="sidebar-menu">
          <li class="active">
            <a class="" href="<?php echo e(route('admin_home')); ?>">
                  <i class="icon_house_alt"></i>
                  <span>Home</span>
            </a>
          </li>
          <li class="sub-menu">
            <a href="javascript:;" class="">
                          <i class="icon_document_alt"></i>
                          <span>Reservation</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
            <ul class="sub">
              <li><a class="" href="">List</a></li>
              <li><a class="" href="">Set</a></li>
            </ul>
          </li>
          
        
          
        </ul>
        
      </div>
    </aside><?php /**PATH C:\Users\estela\Desktop\THESIS\water_billing\resources\views/faculty/side.blade.php ENDPATH**/ ?>