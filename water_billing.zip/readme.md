Setup
1. clone
2. cp .env.example .env
3. composer install
4. agto sa .env e setup imo mysql
5. php artisan key:generate
6. php artisan migrate --seed
