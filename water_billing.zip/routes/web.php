<?php

Route::get('/', function () 
{
    return redirect()->route('login');
});

Route::group(['prefix'=> 'auth'], function()
{
	Route::get('/login', [
		'as' 	=> 'login',
		'uses'	=> 'AuthController@login'
	]);

	Route::post('/login', [
		'as'	=> 'loginCheck',
		'uses'	=> 'AuthController@loginCheck'
	]);
});



//Route::prefix('billing')->group(base_path('routes/billing.php'));

//Route::prefix('cashier')->group(base_path('routes/cashier.php'));

//Route::prefix('client')->group(base_path('routes/client.php'));

//Route::prefix('maintenance')->group(base_path('routes/maintenance.php'));




