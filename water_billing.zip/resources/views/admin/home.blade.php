@extends('admin.template')

@section('styles')

@endsection

@section('contents')
	<h1>HOME</h1>
@endsection

@section('scripts')

@endsection