@extends('client.template')

@section('styles')

@endsection

@section('contents')
	<h1>My Current Balance</h1>
@endsection

@section('scripts')

@endsection