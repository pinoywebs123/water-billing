<aside>
      <div id="sidebar" class="nav-collapse ">
      
        <ul class="sidebar-menu">
          <li class="active">
            <a class="" href="{{route('cashier_home')}}">
                  <i class="icon_house_alt"></i>
                  <span>Home</span>
            </a>
          </li>

          <li >
            <a class="" href="{{route('cashier_client_records')}}">
                  <i class="icon_house_alt"></i>
                  <span>Client Records</span>
            </a>
          </li>

       
          
        
          
        </ul>
        
      </div>
    </aside>