@extends('maintenance.template')

@section('styles')

@endsection

@section('contents')
	<h1>Approved Bills</h1>
@endsection

@section('scripts')

@endsection